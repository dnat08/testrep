
A tool to stress test the SSL handshake by triggering processor intensive
RSA_encrypt() calls on the server side.

See more documentation and paper at:


                    http://www.thc.org/thc-ssl-down

COMPILE
=======

# ./configure
# make all
# src/thc-ssl-down -h


Yours sincerly,

The Hackers Choice
http://www.thc.org

