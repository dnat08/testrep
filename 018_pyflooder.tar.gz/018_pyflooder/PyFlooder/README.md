# PyFlooder
An [HTTP Flood](https://en.m.wikipedia.org/wiki/HTTP_Flood) Python script that could stop a normal website in 10s

# How does it work ?
It generates a configurable number of random GET requests and sends them to the target

# Usage

```
pyflooder.py < Hostname > < Port > < Number_of_Attacks >
```
