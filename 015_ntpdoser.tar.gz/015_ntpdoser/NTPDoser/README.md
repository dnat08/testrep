NTP Doser
===

Introduction.
===
*NTP Doser* is a NTP Amplification DoS tool which code by C/C++.
*NTP Doser* is just a pentesting tool , so don't be evil.

Compiling.
===
    gcc NTPDoser.cpp -o NTPDoser -lstdc++ -lpthread
Running NTP Doser.
===
	sudo ./NTPDoser [target] [threads] [time]
Screenshot.
===
![image](https://github.com/DrizzleRisk/NTPDoser/blob/master/screenshot/help.png)
![image](https://github.com/DrizzleRisk/NTPDoser/blob/master/screenshot/test.png)

License.
===
	Licensed under the Apache License, Version 2.0
